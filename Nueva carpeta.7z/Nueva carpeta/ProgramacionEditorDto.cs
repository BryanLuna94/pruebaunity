﻿namespace Roardsoft.DataTypes.anonymousType
{
    public class ProgramacionEditorDto : tb_STC_Programacion_Cabecera
    {
        public string NombreCliente { get; set; }
        public string FechaInicio { get; set; }
        public string HoraInicio { get; set; }
        public bool ViajeCriticoBln { get; set; }

        public string FechaFin { get; set; }
        public string HoraFin { get; set; }

        public string FechaProgramacion { get; set; }
        public string HoraProgramacion { get; set; }
        public string EstadoProgramacion { get; set; }
        public string Referenciado { get; set; }
    }
}
