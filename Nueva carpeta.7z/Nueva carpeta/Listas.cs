﻿using Roardsoft.DataTypes.anonymousType;
using System.Collections.Generic;

namespace Roardsoft.BusinessLayer.Genericos
{
    public class Listas
    {
        public static List<GenericoDto> ListaEstados()
        {
            var result = new List<GenericoDto>();
            result.Add(new GenericoDto { Codigo = Utility.Constantes.EstadosProgramacion.REGISTRADA, Descripcion = "Registrada" });
            result.Add(new GenericoDto { Codigo = Utility.Constantes.EstadosProgramacion.AUTORIZADA, Descripcion = "Autorizada" });
            result.Add(new GenericoDto { Codigo = Utility.Constantes.EstadosProgramacion.FACTURADA, Descripcion = "Facturada" });
            result.Add(new GenericoDto { Codigo = Utility.Constantes.EstadosProgramacion.ANULADA, Descripcion = "Anulada" });
            return result;
        }
    }
}
