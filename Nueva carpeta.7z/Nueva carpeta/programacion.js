﻿
var programacion = {
    idFormGrid: "#programacionGridForm",
    idFormEditor: "#programacionEditorForm",
    idFormEditorDetalle: "#programacionDetalleEditorForm",
    idFormEditorTripulacion: "#programacionTripulacionEditorForm",
    idFormEditorUnidad: "#programacionUnidadEditorForm",
    updateTargetIdGrid: "#programacion-wrapper",
    updateTargetIdGridDetalle: "#detalle-wrapper",
    updateTargetIdGridTripulacion: "#programacionTripulacion-wrapper",
    updateTargetIdGridDetalleParametros: "#programacionDetalleParametros-wrapper",
    updateTargetIdGridUnidad: "#programacionUnidad-wrapper",

    grid: {
        load: function () {

            $("#Filtro_ID_Index").keypress(function (e) {
                if (e.which == 13) {
                    e.preventDefault();
                    baseGrid.find(route.programacion, programacion.idFormGrid, "Refrescar", programacion.updateTargetIdGrid);
                }
            });

            $("#Filtro_NumeroTransporte").keypress(function (e) {
                if (e.which == 13) {
                    e.preventDefault();
                    baseGrid.find(route.programacion, programacion.idFormGrid, "Refrescar", programacion.updateTargetIdGrid);
                }
            });

            $("#Filtro_TbEstado_Id").change(function (e) {
                baseGrid.find(route.programacion, programacion.idFormGrid, "Refrescar", programacion.updateTargetIdGrid);
            });

            $('#Filtro_FiltroFechaInicio').daterangepicker({ language: "es", format: 'DD/MM/YYYY' })
            $('#Filtro_FiltroFechaFin').daterangepicker({ language: "es", format: 'DD/MM/YYYY' })

            baseGrid.init(route.programacion, programacion.idFormGrid, programacion.updateTargetIdGrid, programacion.editor.init);
        },

        eliminar: function (id) {
            baseGrid.ejecutar(route.programacion, "eliminar", id, programacion.idFormGrid, programacion.updateTargetIdGrid, undefined, "¿Realmente desea eliminar esta programacion?", undefined, "programacion eliminada :(");
        },

        restaurar: function (id) {
            baseGrid.ejecutar(route.programacion, "restaurar", id, programacion.idFormGrid, programacion.updateTargetIdGrid, undefined, "¿Realmente desea restaurar esta programacion?", undefined, "programacion Restaurada :)");
        },

        detalle: function (id) {
            var opciones = {
                metodo: function () {
                    $(programacion.idFormEditor).find('input, textarea, button, select').attr('disabled', 'disabled');
                }
            }
            baseEditor.init(route.programacion, id, "Detalle de programacion", dialog.normal, undefined, opciones.metodo, "Detalle", false, true);
        },

        entregaDinero: function (id) {
            baseEditor.initComplete(route.entregaDinero, id, undefined, undefined, "Index");
        }




    },

    editorDetalle: {

        init: function (id, indice, torigen, tdestino, fact, idOrigen, idDestino, NroTransporte, ItemVacio, idGeneral) {
            var ruc = $("#Programacion_RUC_Cliente").val();
            var est = $("#ProgramacionParametros_Region").val();
            var title = "";
            if (id == "1") {
                title = "AGREGAR REFERENCIA";
                $(".item-vacio").hide();
                $(".chk-vacio").hide();
            } else if (id == "3") {
                title = "AGREGAR DESTINO";
            } else {
                title = "AGREGAR ORIGEN Y DESTINO";
            }


            var model = {
                Indice: indice,
                Id_Key: $("#Programacion_ID_Key").val(),
                Id_Index: $("#Programacion_ID_Index").val(),
                Tipo: id,
                TipoOrigen: torigen,
                TipoDestino: tdestino,
                Facturable: fact,
                IdOrigen: idOrigen,
                IdDestino: idDestino,
                IdGeneral: idGeneral,
                NroTransporte: NroTransporte,
                ItemVacio: ItemVacio
            };

            baseEditor.init(route.programacion, undefined, title, dialog.normal, model, undefined, "EditorDetalle", true, true, "Aplicar", "Cerrar", true);
        },

        ocultarMostrarItemVacio: function () {
            if ($('#Chkvacio').is(':checked')) {
                $(".item-vacio").hide();
            } else {
                $(".item-vacio").show();
            };
        },

        load: function () {
            var formContent = $(programacion.idFormEditorDetalle);
            var formContentEditor = $(programacion.idFormEditor);
            formContent.find("#Detalle_ID_Index").val(formContentEditor.find("#Programacion_ID_Index").val());
            var id = $("#Tipo").val();
            var F = $("#Facturable").val();
            if (id == "1") {
                $(".item-vacio").hide();
                $(".chk-vacio").hide();
            } else {
                if (F == "SI") {
                    $(".chk-vacio").hide();
                }
                else {
                    programacion.editorDetalle.ocultarMostrarItemVacio();
                    $("#Chkvacio").change(function (e) {
                        programacion.editorDetalle.ocultarMostrarItemVacio();

                    });
                }

            }

            programacion.editorDetalle.validation(formContent);

            $("#btnAgregar").click(function (e) {
                programacion.editorDetalle.agregarParametro();
            });

            $("#Chkvacio").change(function (e) {
                programacion.editorDetalle.ocultarMostrarItemVacio();
            });



        },

        validation: function (formContent) {
            $(formContent).formValidation({
                framework: 'bootstrap',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    "Detalle.Mer_Nombre": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "Detalle.IdOrigen": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "Detalle.IdDestino": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    }
                }
            })
                .on('success.form.fv', function (e) {
                    e.preventDefault();

                    programacion.editorDetalle.agregar();
                });
        },

        agregar: function () {

            var indice = $("#Indice").val();
            var facturable = $("#Facturable").val();
            var bFacturable = (facturable == "SI") ? "True" : "False";
            var id = $("#Tipo").val();
            var ItemVacio = ""
            if ($('#Chkvacio').is(':checked')) {
                ItemVacio = "true";
            } else {
                ItemVacio = "false";
            };
            if (id == "1") {

                var referencia = $("#IdGeneral option:selected").text();
                var codigo = $("#IdGeneral").val();
                var arreglo = referencia.split(" - ");
                var arregloCodigo = codigo.split("-");
                var origen = arreglo[0];
                var destino = arreglo[1];
                var idOrigen = arregloCodigo[0];
                var idDestino = arregloCodigo[1];
                var Index_Referencia = arregloCodigo[2];
                $("#origen_" + indice).html(origen);
                $("#destino_" + indice).html(destino);

                $("#ListaDetalle_" + indice + "__IdOrigen").val(idOrigen);
                $("#ListaDetalle_" + indice + "__IdDestino").val(idDestino);
                $("#ListaDetalle_" + indice + "__Index_Referencia").val(Index_Referencia);
                indice++;
                $("#origen_" + indice).html(destino);
                $("#ListaDetalle_" + indice + "__IdOrigen").val(idDestino);

            } else if (id == "2") {

                var origen = $("#IdOrigen option:selected").text();
                var destino = $("#IdDestino option:selected").text();
                var idOrigen = $("#IdOrigen").val();
                var idDestino = $("#IdDestino").val();

                $("#origen_" + indice).html(origen);
                $("#destino_" + indice).html(destino);
                $("#ListaDetalle_" + indice + "__IdOrigen").val(idOrigen);
                $("#ListaDetalle_" + indice + "__IdDestino").val(idDestino);
                indice++;
                $("#origen_" + indice).html(destino);
                $("#ListaDetalle_" + indice + "__IdOrigen").val(idDestino);

            } else {

                var destino = $("#IdGeneral option:selected").text();
                var idDestino = $("#IdGeneral").val();
                $("#destino_" + indice).html(destino);
                $("#ListaDetalle_" + indice + "__IdDestino").val(idDestino);
                indice++;
                $("#origen_" + indice).html(destino);
                $("#ListaDetalle_" + indice + "__IdOrigen").val(idDestino);

            }

            indice--;
            var item = indice + 1;

            $("#ListaDetalle_" + indice + "__NroTransporte").val($("#NroTransporte").val());
            $("#ListaDetalle_" + indice + "__Item").val(item);
            $("#ListaDetalle_" + indice + "__Facturable").val(bFacturable);
            $("#ListaDetalle_" + indice + "__ItemVacio").val(ItemVacio);

            $("#eliminar_" + indice).show();

            if (indice == 0) {
                $("#ProgramacionParametros_Region").attr("disabled", "disabled");
                $("#ProgramacionParametros_RutaViaje").attr("disabled", "disabled");
                $("#ProgramacionParametros_TipoServicio").attr("disabled", "disabled");
            }

            programacion.editor.anularModificacionCabeceraSiTieneTramos();

            //$("#eliminar_" + indice).html("<h4 class='text-green'><i class='icon fa fa-check'></i> Completo!</h4>");

        },

        agregarParametro: function () {
            if ($("#Tripulacion_Ben_Codigo").val() == "") {
                mensaje.advertencia("Ingrese un personal");
                return;
            }

            var options = {
                onSuccessComplete: function (data) {
                    $("#Serie").val("");
                    $("#Numero").val("");
                    $(programacion.updateTargetIdGridDetalleParametros).html(data);
                }
            };
            baseGrid.ejecutar(route.programacion, "insertardetalleparametro", undefined, undefined, programacion.updateTargetIdGridDetalleParametros, $(programacion.idFormEditorDetalle).serialize(), undefined, options.onSuccessComplete);
        },

        eliminarParametro: function (id) {

            var model = {
                ID_Index: $("#Id_Index").val(),
                Item: $("#Indice").val(),
                ID_Key: id
            }

            var options = {
                onSuccessComplete: function (data) {
                    $(programacion.updateTargetIdGridDetalleParametros).html(data);
                }
            };
            baseGrid.ejecutar(route.programacion, "EliminarDetalleParametro", undefined, undefined, undefined, model, undefined, options.onSuccessComplete);
        },

        eliminar: function (id) {
            baseGrid.ejecutar(route.programacion, "EliminarDetalle", id, programacion.idFormEditorDetalle, programacion.updateTargetIdGridDetalle, undefined, "¿Realmente desea eliminar este registro?", undefined, "Registro eliminado");
        }
    },

    editorTripulacion: {
        init: function (id) {
            var title = "Agregar Tripulacion";
            if (programacion.editor.validaProgramacionEstaAnulada_Facturada() == "1" || programacion.editor.validaProgramacionEstaCerrada() == "1") {
                baseEditor.init(route.programacion, id, title, dialog.normal, undefined, undefined, "EditorTripulacion", false);
            }
            else {
                baseEditor.init(route.programacion, id, title, dialog.normal, undefined, undefined, "EditorTripulacion");
            }

        },

        load: function () {
            var formContent = $(programacion.idFormEditorTripulacion);
            var formContentEditor = $(programacion.idFormEditor);
            formContent.find("#TractoParametros_ID_Index").val(formContentEditor.find("#Programacion_ID_Index").val());

            var options = {
                onSuccessComplete: function (response, data) {
                    response($.map(data, function (item) {
                        $("#TractoParametros_TractoCodigo").val("");
                        return { label: item.Descripcion, value: item.Descripcion, captura: item.Codigo };
                    }))
                },
                select: function (event, ui) {
                    var codigo = ui.item.captura;
                    $("#TractoParametros_TractoCodigo").val(codigo);
                    programacion.editorTripulacion.listarParametrosTracto(codigo);
                }
            };
            baseGrid.autocomplete(route.unidad, "ListaUnidades", "TractoParametros_Tracto", options.onSuccessComplete, options.select);

            var options = {
                onSuccessComplete: function (response, data) {
                    response($.map(data, function (item) {
                        $("#TractoParametros_CarretaCodigo").val("");
                        return { label: item.Descripcion, value: item.Descripcion, captura: item.Codigo };
                    }))
                },
                select: function (event, ui) {
                    $("#TractoParametros_CarretaCodigo").val(ui.item.captura);
                }
            };
            baseGrid.autocomplete(route.unidad, "ListaCarretas", "TractoParametros_Carreta", options.onSuccessComplete, options.select);

            var options = {
                onSuccessComplete: function (response, data) {
                    response($.map(data, function (item) {
                        $("#TractoParametros_PilotoCodigo").val("");
                        return { label: item.Descripcion, value: item.Descripcion, captura: item.Codigo };
                    }))
                },
                select: function (event, ui) {
                    $("#TractoParametros_PilotoCodigo").val(ui.item.captura);
                }
            };
            baseGrid.autocomplete(route.personal, "ListaPersonal", "TractoParametros_Piloto", options.onSuccessComplete, options.select);

            programacion.editorTripulacion.validation(formContent);
        },

        listarParametrosTracto: function (id) {
            var options = {
                onSuccessComplete: function (data) {
                    $("#TractoParametros_Carreta").val(data.Carreta);
                    $("#TractoParametros_CarretaCodigo").val(data.CarretaCodigo);
                    $("#TractoParametros_Piloto").val(data.Piloto);
                    $("#TractoParametros_PilotoCodigo").val(data.PilotoCodigo);
                }
            };
            baseGrid.ejecutar(route.unidad, "ListaParametrosTracto", id, undefined, undefined, undefined, undefined, options.onSuccessComplete, "");
        },

        validation: function (formContent) {
            $(formContent).formValidation({
                framework: 'bootstrap',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    "TractoParametros.Carreta": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "TractoParametros.Tracto": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "TractoParametros.Piloto": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                }
            })
                .on('success.form.fv', function (e) {
                    e.preventDefault();

                    programacion.editorTripulacion.agregar();
                });
        },

        agregar: function () {
            if ($("#TractoParametros_TractoCodigo").val() == "") {
                mensaje.advertencia("Ingrese un tracto");
                return;
            }

            if ($("#TractoParametros_CarretaCodigo").val() == "") {
                mensaje.advertencia("Ingrese una carreta");
                return;
            }

            if ($("#TractoParametros_PilotoCodigo").val() == "") {
                mensaje.advertencia("Ingrese un piloto");
                return;
            }

            baseGrid.modificar(route.programacion, "insertartripulacion", programacion.idFormEditorTripulacion, undefined, undefined);
        },
    },

    editor: {

        init: function (id) {
            baseEditor.initComplete(route.programacion, id);
        },

        loadDetalle: function () {
            var cont = 0;
            $("tr").each(function () {
                if (cont != 0) {
                    var indice = cont - 1;
                    var IdKey = $("#ListaDetalle_" + indice + "__ID_Key").val()

                    if (indice == 0 && IdKey != "0") {
                        $("#ProgramacionParametros_Region").attr("readonly", "readonly");
                        $("#ProgramacionParametros_RutaViaje").attr("readonly", "readonly");
                        $("#ProgramacionParametros_TipoServicio").attr("readonly", "readonly");
                    }

                    if (IdKey == "0") {
                        $("#eliminar_" + indice).hide();
                    }
                }

                cont++;
            });

            $(".complete").click(function (e) {

                if ($("#Programacion_ID_Key").val() == "") {
                    mensaje.advertencia("Primero debe aisgnar una unidad");
                    return;
                }

                var fila = $(this).closest("tr");
                var indice = $(fila).find(".cont").val();

                var orde = $(fila).find(".orde").val();
                var refe = $(fila).find(".refe").val();

                var fact = $(fila).find(".fact").val();
                var tori = $(fila).find(".tori").val();
                var tdes = $(fila).find(".tdes").val();

                if (indice != "0") {
                    var origen = $("#origen_" + indice).text();
                    if (origen == "PLANTA" || origen == "CDA" || origen == "") {
                        mensaje.advertencia("Debe ingresar el tramo anterior");
                        return;
                    }
                }


                var idOrigen = "";
                var idDestino = "";
                var idGeneral = "";
                var NroTransporte = "";
                var id = "0";
                var ItemVacio = "";
                var Index_Referencia = "0";
                if (orde == "1" && refe == "SI") {
                    id = "1";
                } else if (orde == "1" && refe == "NO") {
                    id = "2";
                } else {
                    id = "3";
                }

                if (id == "1") {
                    idGeneral = $("#ListaDetalle_" + indice + "__IdOrigen").val() + "-" + $("#ListaDetalle_" + indice + "__IdDestino").val() + "-" + $("#ListaDetalle_" + indice + "__Index_Referencia").val();

                } else if (id == "2") {
                    idOrigen = $("#ListaDetalle_" + indice + "__IdOrigen").val();
                    idDestino = $("#ListaDetalle_" + indice + "__IdDestino").val();
                } else {
                    idOrigen = $("#ListaDetalle_" + indice + "__IdOrigen").val();
                    idGeneral = $("#ListaDetalle_" + indice + "__IdDestino").val();
                }
                NroTransporte = $("#ListaDetalle_" + indice + "__NroTransporte").val();
                ItemVacio = $("#ListaDetalle_" + indice + "__ItemVacio").val();
                Index_Referencia = $("#ListaDetalle_" + indice + "__Index_Referencia").val();

                programacion.editorDetalle.init(id, indice, tori, tdes, fact, idOrigen, idDestino, NroTransporte, ItemVacio, idGeneral);
            });

            $(".delete").click(function (e) {
                var fila = $(this).closest("tr");
                var indice = $(fila).find(".cont").val();


                indice = (parseInt(indice) + 1).toString();
                var destino = $("#destino_" + indice).text();

                if (!(destino == "PLANTA" || destino == "CDA" || destino == "DESCARTE" || destino == "")) {
                    mensaje.advertencia("Debe eliminar el tramo siguiente");
                    return;
                }
                indice = $(fila).find(".cont").val();


                var Tipo = DevolverTipo($(fila).find(".tdes").val());

                $("#ListaDetalle_" + indice + "__IdDestino").val("");
                $("#destino_" + indice).html(Tipo);
                Tipo = DevolverTipo($("#ListaDetalle_" + (parseInt(indice) + 1) + "__TipoOrigen").val());
                if (Tipo != "") {
                    $("#origen_" + (parseInt(indice) + 1).toString()).html(Tipo);
                }

                if (indice == 0) {
                    Tipo = DevolverTipo($(fila).find(".tori").val());
                    $("#ListaDetalle_" + indice + "__IdOrigen").val("");
                    $("#origen_" + indice).html(Tipo);

                    //$("#ProgramacionParametros_Region").removeAttr('disabled');
                    //$("#ProgramacionParametros_RutaViaje").removeAttr('disabled');
                    //$("#ProgramacionParametros_TipoServicio").removeAttr('disabled');

                }
                $("#eliminar_" + indice).hide();
            });

            function DevolverTipo(TipoCod) {
                var Tipo = "";
                if (TipoCod == "01") {
                    Tipo = "PLANTA"
                }
                else {
                    if (TipoCod == "02") {
                        Tipo = "CDA"
                    }
                    else if (TipoCod == "03") {
                        Tipo = "DESCARTE"
                    }
                }
                return Tipo;
            }

            programacion.editor.ocultaBotonesSegunEstado();
            programacion.editor.ocultaBotonesSegunProgramacionCerrada();
            programacion.editor.anularModificacionCabeceraSiTieneTramos();

        },

        load: function () {
            var formContent = $(programacion.idFormEditor);
            helperFunctions.datepicker(formContent);
            $('.lte-time').timepicker({
                showInputs: false
            })

            var estado = $("#Programacion_EstadoProg").val();
            if (estado == "4" || estado == "3") {
                $("#btnGrabar").hide();
                $("#btnAnular").hide();
                //$("#Programacion_NombreCliente").attr("disabled", "disabled");
                //$("#ProgramacionParametros_Region").attr("disabled", "disabled");


                //document.getElementById("BodyProg").disabled = true
            }
            else {

            }

            if ($("#Programacion_ID_Key").val() != "") {
                $("#Programacion_NombreCliente").attr("readonly", "readonly");
                //$("#ProgramacionParametros_TipoServicio").attr("disabled", "disabled");
                $("#ProgramacionParametros_Region").attr("readonly", "readonly");

            }
            else {

            }
            if ($("#ModificarRuta").val() == "1") {
                $("#ProgramacionParametros_RutaViaje").attr("enabled", "enabled");
            } else {
                $("#ProgramacionParametros_RutaViaje").attr("disabled", "disabled");
            }

            var options = {
                onSuccessComplete: function (response, data) {
                    response($.map(data, function (item) {
                        $("#Programacion_RUC_Cliente").val("");

                        return { label: item.Codigo + " - " + item.Descripcion, value: item.Codigo + " - " + item.Descripcion, captura: item.Codigo };
                    }))
                },
                select: function (event, ui) {
                    $("#Programacion_RUC_Cliente").val(ui.item.captura);
                    programacion.editor.listaPantilla();
                    programacion.editor.obtenerCondicionViaje();
                }
            };
            baseGrid.autocomplete(route.cliente, "ListaClientes", "Programacion_NombreCliente", options.onSuccessComplete, options.select)

            $("#Programacion_NombreCliente").keydown(function (e) {
                if (e.keyCode == 8) {
                    programacion.editor.limpiarPorCliente();
                }
            });

            $("#btnTripulacion").click(function (e) {
                $("#proceso").val("tripulacion");
            });

            $("#btnAnular").click(function (e) {
                programacion.editor.anularProgramacion();
            });

            $("#btnUnidad").click(function (e) {
                $("#proceso").val("unidad");
            });

            $("#btnGrabar").click(function (e) {

                var completo = true;
                $('#tbodylst tr').each(function () {
                    $(this).children("td").each(function (index2) {
                        if (index2 == 1 || index2 == 2) {
                            var texto = $(this).text();
                            if (texto == 'CDA' || texto == 'PLANTA' || texto == 'DESCARTE') {
                                completo = false;
                            }
                        }
                    });
                });

                if (completo == true)
                    $("#proceso").val("grabar");
                else
                    $("#proceso").val("");
            });

            $("#ProgramacionParametros_TipoServicio").change(function (e) {
                $("#CondicionViaje").val("");
                programacion.editor.listaPantilla();
            });

            $("#ProgramacionParametros_RutaViaje").change(function (e) {
                programacion.editor.listarRegiones($(this).val());
            });

            programacion.editor.ocultaBotonesSegunProgramacionCerrada();
            programacion.editor.ocultaBotonesSegunEstado();
            programacion.editor.anularModificacionCabeceraSiTieneTramos();
            programacion.editor.validation(formContent);
        },

        anularProgramacion: function () {
            var id = $("#Programacion_ID_Index").val();

            var options = {
                onSuccessComplete: function (data) {
                    mensaje.informacion(data.Codigo, data.Descripcion);
                }
            };

            baseGrid.ejecutar(route.programacion, "anular", id, undefined, undefined, undefined, "¿Realmente desea anular esta programación?", options.onSuccessComplete, "");
        },

        limpiarPorCliente: function () {
            $('#ProgramacionParametros_TipoServicio option').eq(0).prop('selected', true);
            $("#CondicionViaje").val("");
            $("#Programacion_RUC_Cliente").val("");
            $("#tbodylst").empty();
        },

        obtenerCondicionViaje: function () {

            if ($("#Programacion_RUC_Cliente").val() == "") return;
            if ($("#ProgramacionParametros_TipoServicio").val() == "") return;

            var request = {
                RUC_Cliente: $("#Programacion_RUC_Cliente").val(),
                TipoViaje: $("#ProgramacionParametros_TipoServicio").val(),
            };

            var options = {
                onSuccessComplete: function (data) {
                    $("#CondicionViaje").val(data);
                }
            };
            baseGrid.ejecutar(route.programacion, "obtenercondicionviaje", undefined, undefined, undefined, request, undefined, options.onSuccessComplete, "");
        },

        listaPantilla: function () {

            if ($("#Programacion_RUC_Cliente").val() == "") return;
            if ($("#ProgramacionParametros_TipoServicio").val() == "") return;

            var request = {
                RUC_Cliente: $("#Programacion_RUC_Cliente").val(),
                TipoViaje: $("#ProgramacionParametros_TipoServicio").val(),
            };

            var options = {
                onSuccessComplete: function () {
                    var condicion = $("#CondicionViajeHdn").val();
                    $("#CondicionViaje").val(condicion);
                }
            };

            baseGrid.find(route.programacion, undefined, "ListarPlantilla", programacion.updateTargetIdGridDetalle, undefined, undefined, request, options.onSuccessComplete);
        },

        validation: function (formContent) {
            $(formContent).formValidation({
                framework: 'bootstrap',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    "Programacion.FechaProgramacion": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "ProgramacionParametros.TipoServicio": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "ProgramacionParametros.CondicionViaje": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "ProgramacionParametros.TipoCarga": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "ProgramacionParametros.RutaViaje": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    },
                    "ProgramacionParametros.Region": {
                        validators: {
                            notEmpty: {
                                message: 'Este campo es obligatorio'
                            }
                        }
                    }
                }
            })
                .on('success.form.fv', function (e) {
                    e.preventDefault();

                    var id = $(programacion.idFormEditor + " #Programacion_ID_Key").val();
                    if (id === "")
                        programacion.editor.agregar();
                    else
                        programacion.editor.modificar();
                });
        },

        agregar: function () {

            if ($("#Programacion_RUC_Cliente").val() == "") {
                mensaje.advertencia("Ingrese un cliente");
                return;
            }

            //var proceso = $("#proceso").val();
            //if (proceso == "") {
            //    mensaje.advertencia("Debe completar la plantilla");
            //    return;
            //}

            var options = {
                onSuccessComplete: function (data) {
                    $("#Programacion_ID_Key").val(data.ID_Key);
                    $("#Programacion_ID_Index").val(data.ID_Index);

                    var proceso = $("#proceso").val();
                    if (proceso == "unidad") {
                        programacion.editorUnidad.init(data.ID_Index);
                    } else if (proceso == "tripulacion") {
                        programacion.editorTripulacion.init(data.ID_Index);
                    } else if (proceso == "detalle") {
                        programacion.editorDetalle.init(data.ID_Index);
                    } else {
                        mensaje.informacion("Se guardaron datos exitosamente", "Programacion/Index");
                    }
                }
            };
            baseGrid.ejecutar(route.programacion, "agregar", undefined, programacion.idFormEditor, undefined, $(programacion.idFormEditor).serialize(), undefined, options.onSuccessComplete);
        },

        modificar: function () {
            if ($("#Programacion_RUC_Cliente").val() == "") {
                mensaje.advertencia("Ingrese un cliente");
            }

            //var proceso = $("#proceso").val();
            //if (proceso == "") {
            //    mensaje.advertencia("Debe completar la plantilla");
            //    return;
            //}

            var options = {
                onSuccessComplete: function (data) {

                    var index = $("#Programacion_ID_Index").val();

                    var proceso = $("#proceso").val();
                    if (proceso == "unidad") {
                        programacion.editorUnidad.init(index);
                    } else if (proceso == "tripulacion") {
                        programacion.editorTripulacion.init(index);
                    } else if (proceso == "detalle") {
                        programacion.editorDetalle.init(index);
                    } else {
                        mensaje.informacion(data.Codigo, data.Descripcion);
                    }
                }
            };

            baseGrid.ejecutar(route.programacion, "modificar", undefined, programacion.idFormEditor, undefined, $(programacion.idFormEditor).serialize(), undefined, options.onSuccessComplete, "");
        },

        listarRegiones: function (id) {
            baseGrid.find(route.programacion, undefined, "ListaRegiones", $("#div-region"), undefined, id);
        },

        anularModificacionCabeceraSiTieneTramos() {
            if (programacion.editor.validaTieneTramos() == "1") {
                $("#ProgramacionParametros_TipoServicio").attr("disabled", "disabled");
                $("#ProgramacionParametros_RutaViaje").attr("disabled", "disabled");
                $("#ProgramacionParametros_Region").attr("disabled", "disabled");
            } else {
                $("#ProgramacionParametros_TipoServicio").removeAttr("disabled");
                $("#ProgramacionParametros_RutaViaje").removeAttr("disabled");
                $("#ProgramacionParametros_Region").removeAttr("disabled");
            }
        },

        validaTieneTramos: function () {
            var result = "0"
            $("input[name='hdnOrigen']").each(function () {
                alert($(this).val());
                if ($(this).val() != "") {
                    return "1";
                }
            });
            return result;
        },

        validaProgramacionEstaAnulada_Facturada: function () {
            var result = "0"
            if ($("#Programacion_EstadoProgramacion").val() == "3" || $("#Programacion_EstadoProgramacion").val() == "4") {
                result == "1"
            }
            return result;
        },

        ocultaBotonesSegunEstado: function () {
            if (programacion.editor.validaProgramacionEstaAnulada_Facturada() == "1") {
                $(".botoneria").hide();
            } else {
                $(".botoneria").show();
            }
        },

        validaProgramacionEstaCerrada: function () {
            if ($("#Programacion_EstadoProg").val() == "1") {
                return "1";
            } else {
                return "0";
            }
        },

        ocultaBotonesSegunProgramacionCerrada() {
            if (programacion.editor.validaProgramacionEstaCerrada() == "1") {
                $("#prog_cerrada").html("Cerrada");
                $(".botoneria").hide();
            } else {
                $("#prog_cerrada").html("");
                $(".botoneria").show();
            }
        },

    }
}