﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roardsoft.Utility
{
    public class Constantes
    {
        public class Mensajes
        {
            public const string USUARIO_NO_EXISTE = "Usuario inválido";
            public const string CLAVE_INCORRECTA = "La clave ingresada es incorrecta";
            public const string USUARIO_NO_ACTIVO = "Acceso denegado. Su usuario se encuentra actualmente ";
            public const string EMPRESARIO_EXISTE = "Sr. Empresario, este documento de identidad ya fué registrado anteriomente.";
            public const string PERFIL_EXISTE = "El perfil que intenta registrar ya existe.";
            public const string CODIGO_INCORRECTO = "El código ingresado es incorrecto, comuníquese al 947332996 para mas información.";
            public const string EMPRESA_DOCUMENTO_EXISTE = "Sr. Empresario, Ud. ya registró este RUC anteriomente.";
            public const string EMPRESA_TIENE_SOLICITUD = "Sr. Empresario, esta empresa ya tiene una solicitud de cambio de plan en estado ";
            public const string EMPRESA_SOLICITUD_CAMBIOPLAN = "Sr. Empresario, su solicitud de cambio de plan se ha emitido exitosamente, a partir del próximo ciclo de facturación se le activará su nuevo plan.";
            public const string EMPRESARIO_DATOS_REGISTRADO = "Felicidades! ya tiene su propio sistema comercial, podrá administrar su negocio desde aquí. Para acceso a usuarios de su empresa ingrese a ";
            public const string EMPRESA_CAMBIOPLAN_ENPROCESO = "Sr. Empresario, su cambio de plan está en proceso";
        }

        public class Aplicacion
        {
            public const string EMPRESA_ID = "01";
            public const string APLICACION_ID = "3";
            public const string MODULO_ID = "3001";
        }

        public class Codigos
        {
            public const string TIPOVIAJE_OW = "01";
            public const string TIPOUNIDAD_UNIDAD = "1";
        }

        public class TipoUnidad
        {
            public const string UNIDAD = "01";
            public const string CARRETA = "02";
        }

        public class TipoTripulacion
        {
            public const string PILOTO = "01";
        }

        public class TipoMoneda
        {
            public const string SOLES = "01";
            public const string DOLARES = "02";
        }

        public class TipoTramo
        {
            public const string REFERENCIA = "1";
            public const string ORIGENDESTINO = "2";
            public const string DESTINO = "3";
        }

        public class TipoEntrega
        {
            public const string EFECTIVO = "1";
            public const string BANCO = "2";
        }

        public class TipoDocumento
        {
            public const string ENTREGADINERO = "99";
        }

        public class Liquidacion_TipoMovimiento
        {
            public const string ENTREGADEDINERO = "101";
        }

        public class EstadosProgramacion
        {
            public const string FACTURADA = "3";
            public const string ANULADA = "4";
            public const string REGISTRADA = "1";
            public const string AUTORIZADA = "2";
        }
    }
}
