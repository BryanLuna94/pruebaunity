﻿using Roardsoft.DataAccess;
using Roardsoft.DataTypes;
using Roardsoft.DataTypes.anonymousType;
using Roardsoft.DataTypes.anonymousType.Request;
using Roardsoft.DataTypes.anonymousType.Response;
using Roardsoft.Utility;
using System;
using System.Linq;
using System.Collections.Generic;
using Roardsoft.DataTypes.anonymousType.Filtros;
using Roardsoft.DataTypes.anonymousType.Reporte;

namespace Roardsoft.BusinessLayer
{
    public class ProgramacionLogic
    {
        private static string _TipoServicio = "51";
        private static string _CondicionViaje = "52";
        private static string _TipoCarga = "53";
        private static string _RutaViaje = "54";
        private static string _Region = "56";
        public static ProgramacionResponseDto PaginadoProgramacion(ProgramacionRequestDto request)
        {
            var totalFilas = 0;
            var fechaInicio = request.Programacion.FiltroFechaInicio;
            if (fechaInicio != null)
            {
                if (fechaInicio.Length != 40)
                {
                    BusinessException.Generar("Fecha inicio incorrecta");
                }
                var arregloFecha = fechaInicio.Split('-');
                request.Programacion.FechaHoraInicio_Desde = Convert.ToDateTime(arregloFecha[0]).ToString();
                request.Programacion.FechaHoraInicio_Hasta = Convert.ToDateTime(arregloFecha[1]).ToString();
            }
            var fechaFin = request.Programacion.FiltroFechaFin;
            if (fechaFin != null)
            {
                if (fechaFin.Length != 40)
                {
                    BusinessException.Generar("Fecha fin incorrecta");
                }
                var arregloFecha = fechaFin.Split('-');
                request.Programacion.FechaHoraFin_Desde = Convert.ToDateTime(arregloFecha[0]).ToString();
                request.Programacion.FechaHoraFin_Hasta = Convert.ToDateTime(arregloFecha[1]).ToString();
            }
            var resultado = tb_STC_Programacion_CabeceraData.ProgramacionPaginado(request.Programacion, request.CriteriosPaginacion, ref totalFilas);

            var result = new ProgramacionResponseDto()
            {
                ListaProgramaciones = resultado,
                CriteriosPaginacion = request.CriteriosPaginacion,
                TotalItems = totalFilas,
                ListaParaPaginar = Funciones.Generales.ListadoPaginacion(totalFilas),
                CamposListar = tb_Configuracion_CamposListarData.CamposListar(1)
            };

            return result;
        }

        public static ProgramacionResponseDto ObtenerEditor(string RutaViaje_Codigo, string Id, int PerfilId)
        {
            var programacion = tb_STC_Programacion_CabeceraData.GetProgramacion(Id);
            var listaDetalle = new List<ProgramacionDetalleDto>();
            var programacionParametros = new ProgramacionParametrosDto();
            var listaregiones = new List<GenericoDto>();
            if (programacion != null)
            {
                listaDetalle = ListaDetalle(programacion.ID_Index.ToString());

                //listados registros de tabla de parametros
                var listaPrametros = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaParametrosProgramacion(programacion.ID_Index);
                programacionParametros.TipoServicio = listaPrametros.Single(x => x.TBG_Tabla == _TipoServicio).TBG_Codigo;
                programacionParametros.CondicionViaje = listaPrametros.Single(x => x.TBG_Tabla == _CondicionViaje).TBG_Codigo;
                programacionParametros.TipoCarga = listaPrametros.Single(x => x.TBG_Tabla == _TipoCarga).TBG_Codigo;
                programacionParametros.Region = listaPrametros.Single(x => x.TBG_Tabla == _Region).TBG_Codigo;
                programacionParametros.RutaViaje = listaPrametros.Single(x => x.TBG_Tabla == _RutaViaje).TBG_Codigo;
                RutaViaje_Codigo = programacionParametros.RutaViaje;

                //estado
                programacion.EstadoProgramacion = Genericos.Listas.ListaEstados().Single(x => x.Codigo == programacion.EstadoProg.ToString()).Descripcion;
            }
            else
            {
                programacionParametros.RutaViaje = RutaViaje_Codigo;
            }

            var result = new ProgramacionResponseDto
            {
                Programacion = programacion,
                ListaDetalle = listaDetalle,
                ProgramacionParametros = programacionParametros,
                ListaCondicionViaje = TbgData.ListarPorTabla(_CondicionViaje),
                ListaRutaViaje = TbgData.ListarPorTabla(_RutaViaje),
                ListaTipoCarga = TbgData.ListarPorTabla(_TipoCarga),
                ListaTipoServicio = TbgData.ListarPorTabla(_TipoServicio),
                ListaRegiones = ListarRegiones(RutaViaje_Codigo),
                RutaViaje = TbgData.ListarPorTabla(_RutaViaje).Single(x => x.Codigo == RutaViaje_Codigo).Descripcion,
                CondicionViaje = (programacionParametros.CondicionViaje != null) ? TbgData.ListarPorTabla(_CondicionViaje).Single(x => x.Codigo == programacionParametros.CondicionViaje).Descripcion : "",
                ModificarRuta = Funciones.Web.ConvertirBoleanEnCadena(new Genericos.Permisos(PerfilId).puedeModificarRutaProgramacion)
            };

            return result;
        }

        public static List<GenericoDto> ListarRegiones(string Id)
        {
            return TbgData.ListarPorTablaDetalle(_Region, _RutaViaje, Id);
        }

        public static tb_STC_Programacion_Cabecera InsertarProgramacion(ProgramacionRequestDto request)
        {
            try
            {
                //insertamos cabecera
                var index = tb_CorrelativoDocumentosData.GetCorrelativo(13);
                var Id_Index = Convert.ToDecimal(DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString("0#") + index.ToString("00000000#"));
                var entidad = new tb_STC_Programacion_Cabecera
                {
                    Cerrado = false,
                    Emp_Codigo = request.ProgramacionEditor.Emp_Codigo,
                    FechaHoraFin = Convert.ToDateTime(request.ProgramacionEditor.FechaProgramacion),
                    FechaHoraInicio = Convert.ToDateTime(request.ProgramacionEditor.FechaProgramacion),
                    FechaHoraProgramacion = Convert.ToDateTime(request.ProgramacionEditor.FechaProgramacion),
                    Glosa = request.ProgramacionEditor.Glosa ?? string.Empty,
                    ID_Index = Id_Index,
                    ID_Moneda = request.ProgramacionEditor.ID_Moneda,
                    IGV = request.ProgramacionEditor.IGV,
                    IncluyeIGV = request.ProgramacionEditor.IncluyeIGV,
                    NumeroTransporte = request.ProgramacionEditor.NumeroTransporte ?? string.Empty,
                    Ofi_Codigo = request.ProgramacionEditor.Ofi_Codigo,
                    RUC_Cliente = request.ProgramacionEditor.RUC_Cliente,
                    Suc_Codigo = request.ProgramacionEditor.Suc_Codigo,
                    Usr_Codigo_Registro = request.ProgramacionEditor.Usr_Codigo_Registro,
                    Total = request.ProgramacionEditor.Total,
                    VVenta = request.ProgramacionEditor.VVenta,
                    Viajecritico = request.ProgramacionEditor.ViajeCriticoBln
                };
                var id = tb_STC_Programacion_CabeceraData.Insertar(entidad);
                entidad.ID_Key = id;
                var index_nuevo = Convert.ToInt32(index) + 1;
                tb_CorrelativoDocumentosData.UpdateCorrelativo(13, index_nuevo);

                //insertamos tabla de parametros
                var parametros = request.ProgramacionParametros;

                var entidadTipoServicio = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    Item = 1,
                    TBG_Tabla = _TipoServicio,
                    TBG_Codigo = parametros.TipoServicio
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Insertar(entidadTipoServicio);

                //condicion de viaje
                var objCondicionCliente = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaModoViajePorCliente(entidad.RUC_Cliente, parametros.TipoServicio);
                var entidadCondicionViaje = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    Item = 2,
                    TBG_Tabla = _CondicionViaje,
                    TBG_Codigo = objCondicionCliente.Codigo
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Insertar(entidadCondicionViaje);

                var entidadTipoCarga = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    Item = 3,
                    TBG_Tabla = _TipoCarga,
                    TBG_Codigo = parametros.TipoCarga
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Insertar(entidadTipoCarga);

                var entidadRutaViaje = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    Item = 4,
                    TBG_Tabla = _RutaViaje,
                    TBG_Codigo = parametros.RutaViaje
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Insertar(entidadRutaViaje);

                var entidadRegion = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    Item = 5,
                    TBG_Tabla = _Region,
                    TBG_Codigo = parametros.Region
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Insertar(entidadRegion);

                //insertamos liquidacion
                var entidadLiquidacion = new tb_STC_Programacion_Liquidacion_Cabecera
                {
                    Cerrado = false,
                    Cierre_FechaHora = new DateTime(1900, 1, 1),
                    Cierre_Observacion = string.Empty,
                    Cierre_Usuario = string.Empty,
                    ID_Index = Id_Index,
                    ID_Index_TipoCierre = 0,
                    Importe_Asignado = 0,
                    Importe_Cierre = 0,
                    Importe_Liquidado = 0,
                    Usr_Registro = entidad.Usr_Codigo_Registro
                };
                tb_STC_Programacion_Liquidacion_CabeceraData.Insertar(entidadLiquidacion);

                //insertamos anx
                var entidadANX = new tb_STC_Programacion_Cabecera_ANX
                {
                    ID_Index = Id_Index,
                    ID_Application = Convert.ToByte(Constantes.Aplicacion.APLICACION_ID),
                    ID_Modulo = Convert.ToByte(Constantes.Aplicacion.APLICACION_ID) //muy grande para byte
                };
                tb_STC_Programacion_Cabecera_ANXData.Insertar(entidadANX);
                //retornamos programacion cabecera
                return entidad;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static void Editar(ProgramacionRequestDto request)
        {
            try
            {
                var entidadAnterior = tb_STC_Programacion_CabeceraData.GetProgramacion(request.ProgramacionEditor.ID_Index.ToString());
                var entidadParametrosAnterior = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaParametrosProgramacion(request.ProgramacionEditor.ID_Index);
                var programacionParametros = new ProgramacionParametrosDto();
                programacionParametros.TipoServicio = entidadParametrosAnterior.Single(x => x.TBG_Tabla == _TipoServicio).TBG_Codigo;
                programacionParametros.CondicionViaje = entidadParametrosAnterior.Single(x => x.TBG_Tabla == _CondicionViaje).TBG_Codigo;
                programacionParametros.TipoCarga = entidadParametrosAnterior.Single(x => x.TBG_Tabla == _TipoCarga).TBG_Codigo;
                programacionParametros.Region = entidadParametrosAnterior.Single(x => x.TBG_Tabla == _Region).TBG_Codigo;
                programacionParametros.RutaViaje = entidadParametrosAnterior.Single(x => x.TBG_Tabla == _RutaViaje).TBG_Codigo;
                var entidad = new tb_STC_Programacion_Cabecera
                {
                    FechaHoraFin = Convert.ToDateTime(request.ProgramacionEditor.FechaProgramacion),
                    FechaHoraInicio = Convert.ToDateTime(request.ProgramacionEditor.FechaProgramacion),
                    FechaHoraProgramacion = Convert.ToDateTime(request.ProgramacionEditor.FechaProgramacion),
                    Glosa = request.ProgramacionEditor.Glosa ?? string.Empty,
                    ID_Key = request.ProgramacionEditor.ID_Key,
                    ID_Moneda = request.ProgramacionEditor.ID_Moneda,
                    IGV = request.ProgramacionEditor.IGV,
                    IncluyeIGV = request.ProgramacionEditor.IncluyeIGV,
                    NumeroTransporte = request.ProgramacionEditor.NumeroTransporte ?? string.Empty,
                    Usr_Codigo_Registro = request.ProgramacionEditor.Usr_Codigo_Registro,
                    Total = request.ProgramacionEditor.Total,
                    RUC_Cliente = entidadAnterior.RUC_Cliente,
                    VVenta = request.ProgramacionEditor.VVenta,
                    Viajecritico = request.ProgramacionEditor.ViajeCriticoBln
                };
                tb_STC_Programacion_CabeceraData.Actualizar(entidad);

                //insertamos tabla de parametros
                var Id_Index = request.ProgramacionEditor.ID_Index;
                var parametros = request.ProgramacionParametros;

                //var entidadTipoServicio = new tb_STC_Programacion_Cabecera_ANX_Parametros
                //{
                //    ID_Index = Id_Index,
                //    TBG_Tabla = _TipoServicio,
                //    TBG_Codigo = parametros.TipoServicio
                //};
                //tb_STC_Programacion_Cabecera_ANX_ParametrosData.Actualizar(entidadTipoServicio);

                //var objCondicionCliente = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaModoViajePorCliente(entidad.RUC_Cliente, parametros.TipoServicio);
                //var entidadCondicionViaje = new tb_STC_Programacion_Cabecera_ANX_Parametros
                //{
                //    ID_Index = Id_Index,
                //    TBG_Tabla = _CondicionViaje,
                //    TBG_Codigo = objCondicionCliente.Codigo
                //};
                //tb_STC_Programacion_Cabecera_ANX_ParametrosData.Actualizar(entidadCondicionViaje);

                var entidadTipoCarga = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    TBG_Tabla = _TipoCarga,
                    TBG_Codigo = parametros.TipoCarga
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Actualizar(entidadTipoCarga);

                var entidadRutaViaje = new tb_STC_Programacion_Cabecera_ANX_Parametros
                {
                    ID_Index = Id_Index,
                    TBG_Tabla = _RutaViaje,
                    TBG_Codigo = (parametros.RutaViaje == null) ? programacionParametros.RutaViaje : parametros.RutaViaje
                };
                tb_STC_Programacion_Cabecera_ANX_ParametrosData.Actualizar(entidadRutaViaje);

                //var entidadRegion = new tb_STC_Programacion_Cabecera_ANX_Parametros
                //{
                //    ID_Index = Id_Index,
                //    TBG_Tabla = _Region,
                //    TBG_Codigo = parametros.Region
                //};
                //tb_STC_Programacion_Cabecera_ANX_ParametrosData.Actualizar(entidadRegion);

                //INSERTANDO DETALLE
                //PRIMERO ELIMINAMOS LO ANTERIOR
                tb_STC_Programacion_DetalleData.EliminarPorCabecera(Id_Index);

                if (request.ListaDetalle != null)
                {
                    foreach (var item in request.ListaDetalle)
                    {

                        if (item.IdDestino != null && item.IdDestino != "")
                        {
                            bool bFacturable;
                            if (item.Facturable == "NO")
                                bFacturable = false;
                            else if (item.Facturable == "SI")
                                bFacturable = true;
                            else
                                bFacturable = Convert.ToBoolean(item.Facturable);

                            var detalle = new tb_STC_Programacion_Detalle
                            {
                                Cantidad = 1,
                                Facturable = bFacturable,
                                FechaHoraRegistro = DateTime.Now,
                                IdDestino = Convert.ToInt32(item.IdDestino),
                                IdOrigen = Convert.ToInt32(item.IdOrigen),
                                ID_Index = Id_Index,
                                Item = item.Item,
                                Mer_Codigo = "319",
                                Total = 0,
                                Usr_Codigo_Registro = entidad.Usr_Codigo_Registro,
                                ItemVacio = item.ItemVacio,
                                ID_IndexRef = item.Index_Referencia
                            };
                            tb_STC_Programacion_DetalleData.Insertar(detalle);
                        }

                        if (item.Index_Referencia == 0)
                        {
                            tb_STC_Programacion_Detalle_ANX_ParametrosData.EliminarTransporte(Id_Index.ToString(), item.Item);
                            if (item.NroTransporte != null)
                            {
                                var ent = new tb_STC_Programacion_Detalle_ANX_Parametros
                                {
                                    ID_Index = Id_Index,
                                    Item = item.Item,
                                    TBG_Codigo = "01",
                                    TBG_Tabla = "59",
                                    Valor = item.NroTransporte
                                };
                                tb_STC_Programacion_Detalle_ANX_ParametrosData.Insertar(ent);
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static List<ProgramacionRegularDto> ListaProgramacionesRegularesPorUnidad(ProgramacionRegularFiltroDto filtro)
        {
            return tb_STC_Programacion_CabeceraData.ListaProgramacionesRegularesPorUnidad(filtro);
        }

        public static GenericoDto ObtenerCondicionViajeCliente(ConfiguracionTipoViajeFiltroDto request)
        {
            try
            {
                var objCondicionCliente = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaModoViajePorCliente(request.RUC_Cliente, request.TipoViaje);
                return objCondicionCliente;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static void AnularProgramacion(string Id_Index, string Usuario)
        {
            try
            {
                tb_STC_Programacion_CabeceraData.Anular(Id_Index, Usuario);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #region DETALLE

        public static List<ProgramacionDetalleDto> ListaDetalle(string ID_Index)
        {
            var programacion = tb_STC_Programacion_CabeceraData.GetProgramacion(ID_Index);
            var programacionParametros = new ProgramacionParametrosDto();
            var listaDetalle = tb_STC_Programacion_DetalleData.ListaDetalle(Convert.ToDecimal(ID_Index), 0);
            var listaPrametros = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaParametrosProgramacion(programacion.ID_Index);
            programacionParametros.TipoServicio = listaPrametros.Single(x => x.TBG_Tabla == _TipoServicio).TBG_Codigo;
            var request = new ConfiguracionTipoViajeFiltroDto
            {
                CondicionViaje = listaPrametros.Single(x => x.TBG_Tabla == _CondicionViaje).TBG_Codigo,
                RUC_Cliente = programacion.RUC_Cliente,
                TipoViaje = listaPrametros.Single(x => x.TBG_Tabla == _TipoServicio).TBG_Codigo
            };
            var listaTramos = tb_STC_ConfiguracionTipoViaje_CData.ListaTramos(request);
            var listaFinal = new List<ProgramacionDetalleDto>();
            var DestinoOrigen = ""; var IdDestinoOrigen = "";
            foreach (var item in listaTramos)
            {
                var entidadDetalle = listaDetalle.FirstOrDefault(x => x.Item == item.OrdenTramo);
                if (entidadDetalle != null)
                {
                    listaFinal.Add(entidadDetalle);
                    DestinoOrigen = entidadDetalle.Destino;
                    IdDestinoOrigen = entidadDetalle.IdDestino;
                }
                else
                {
                    entidadDetalle = new ProgramacionDetalleDto
                    {
                        Destino = item.T_Destino,
                        Facturable = item.Facturable,
                        IdDestino = "",
                        IdOrigen = (IdDestinoOrigen != "") ? IdDestinoOrigen : "",
                        Item = (int)item.OrdenTramo,
                        NroTransporte = "",
                        OrdenTramo = item.OrdenTramo,
                        Origen = (DestinoOrigen != "") ? DestinoOrigen : item.T_Origen,
                        TipoDestino = item.TipoDestino,
                        TipoOrigen = item.TipoOrigen,
                        Referencia = item.Referencia,
                        ItemVacio = false
                    };
                    DestinoOrigen = ""; IdDestinoOrigen = "";
                    listaFinal.Add(entidadDetalle);
                }
            }
            return listaFinal;
        }

        public static Programacion_DetalleResponseDto ObtenerEditorDetalle(Programacion_DetalleRequestDto request)
        {
            try
            {
                var listaGeneral = new List<GenericoDto>();
                var listaOrigen = new List<GenericoDto>();
                var listaDestino = new List<GenericoDto>();

                var programacion = tb_STC_Programacion_CabeceraData.GetProgramacion(request.Id);
                var listaPrametros = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaParametrosProgramacion(programacion.ID_Index);
                var codigoEstacion = listaPrametros.Single(x => x.TBG_Tabla == _Region).TBG_Codigo;

                if (request.Tipo == Constantes.TipoTramo.REFERENCIA)
                {
                    var unidades = tb_STC_Programacion_Cabecera_ANX_UnidadData.ListaProgramacion_Unidades(programacion.ID_Index.ToString()).FirstOrDefault(x => x.Tipo == "UNIDAD");

                    if (unidades == null)
                    {
                        BusinessException.Generar("Debe seleccionar al menos una unidad principal en esta programación");
                    }

                    var programacionRegularFiltro = new ProgramacionRegularFiltroDto
                    {
                        Id = programacion.ID_Index,
                        CodigoUnidad = (unidades != null) ? unidades.Codigo : "",
                        FechaProgramacion = programacion.FechaProgramacion
                    };

                    listaGeneral = tb_STC_Programacion_CabeceraData.ListaProgramacionesRegulares(programacionRegularFiltro);
                }
                else if (request.Tipo == Constantes.TipoTramo.DESTINO)
                {
                    listaGeneral = tb_STC_PuntoAten_Cli_TipoData.ListaPuntosAtencion(request.TipoDestino, programacion.RUC_Cliente, codigoEstacion);
                }
                else
                {
                    listaOrigen = tb_STC_PuntoAten_Cli_TipoData.ListaPuntosAtencion(request.TipoOrigen, programacion.RUC_Cliente, codigoEstacion);
                    listaDestino = tb_STC_PuntoAten_Cli_TipoData.ListaPuntosAtencion(request.TipoDestino, programacion.RUC_Cliente, codigoEstacion);
                }


                var listaDetalleParametros = tb_STC_Programacion_Detalle_ANX_ParametrosData.ListaDetalle(programacion.ID_Index, request.Indice);


                var entidadTransporte = tb_STC_Programacion_Detalle_ANX_ParametrosData.ListaNroTransporte(programacion.ID_Index, request.Indice);

                var transporte = ""; bool? ItemVacio = false; decimal Index_Referencia = 0;

                var listaDetalle = tb_STC_Programacion_DetalleData.ListaDetalle(programacion.ID_Index, request.Indice);
                if (listaDetalle.Count() != 0)
                {
                    transporte = listaDetalle.FirstOrDefault().NroTransporte;
                    ItemVacio = listaDetalle.FirstOrDefault().ItemVacio;
                    Index_Referencia = listaDetalle.FirstOrDefault().Index_Referencia;
                }

                var result = new Programacion_DetalleResponseDto
                {
                    ListaGeneral = listaGeneral,
                    ListaOrigen = listaOrigen,
                    ListaDestino = listaDestino,
                    ListaDetalleParametros = listaDetalleParametros,
                    NroTransporte = transporte,
                    ItemVacio = ItemVacio,
                    Index_Referencia = Index_Referencia
                };

                return result;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public static void InsertarProgramacionDetalle(Programacion_DetalleRequestDto request)
        {
            try
            {
                var entidad = new tb_STC_Programacion_Detalle
                {
                    Cantidad = 1,
                    FechaHoraRegistro = DateTime.Now,
                    IdDestino = request.Detalle.IdDestino,
                    IdOrigen = request.Detalle.IdOrigen,
                    ID_Index = request.Detalle.ID_Index,
                    Item = tb_STC_Programacion_DetalleData.ObtenerItem(request.Detalle.ID_Index.ToString()),
                    Mer_Codigo = request.Detalle.Mer_Codigo,
                    Total = 0,
                    Usr_Codigo_Registro = request.Detalle.Usr_Codigo_Registro
                };

                if (tb_STC_Programacion_DetalleData.ValidaExiste(entidad))
                {
                    BusinessException.Generar("Ya ingreso estos datos anteriomente");
                }

                if (entidad.IdOrigen == entidad.IdDestino)
                {
                    BusinessException.Generar("El origen y el destino deben ser diferentes");
                }

                if (request.NroTransporte != null)
                {
                    var ent = new tb_STC_Programacion_Detalle_ANX_Parametros
                    {
                        ID_Index = entidad.ID_Index,
                        Item = entidad.Item,
                        TBG_Codigo = "01",
                        TBG_Tabla = "59",
                        Valor = request.NroTransporte
                    };
                    tb_STC_Programacion_Detalle_ANX_ParametrosData.Insertar(ent);
                }


                tb_STC_Programacion_DetalleData.Insertar(entidad);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static void EditarProgramacionDetalle(Programacion_DetalleRequestDto request)
        {
            try
            {
                var entidad = new tb_STC_Programacion_Detalle
                {
                    Cantidad = request.Detalle.Cantidad,
                    FechaHoraRegistro = DateTime.Now,
                    IdDestino = request.Detalle.IdDestino,
                    IdOrigen = request.Detalle.IdOrigen,
                    ID_Key = request.Detalle.ID_Key,
                    Mer_Codigo = request.Detalle.Mer_Codigo,
                    Total = request.Detalle.Total,
                    Usr_Codigo_Registro = request.Detalle.Usr_Codigo_Registro,
                    Item = request.Detalle.Item
                };
                tb_STC_Programacion_DetalleData.Actualizar(entidad);

                tb_STC_Programacion_Detalle_ANX_ParametrosData.EliminarTransporte(entidad.ID_Index.ToString(), entidad.Item);
                if (request.NroTransporte != null)
                {
                    var ent = new tb_STC_Programacion_Detalle_ANX_Parametros
                    {
                        ID_Index = entidad.ID_Index,
                        Item = entidad.Item,
                        TBG_Codigo = "01",
                        TBG_Tabla = "59",
                        Valor = request.NroTransporte
                    };
                    tb_STC_Programacion_Detalle_ANX_ParametrosData.Insertar(ent);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static decimal EliminarProgramacionDetalle(long id)
        {
            try
            {
                var entidad = tb_STC_Programacion_DetalleData.GetProgramacionDetalle(id);
                tb_STC_Programacion_DetalleData.Eliminar(id);
                return entidad.ID_Index;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static ConfiguracionTipoViajeResponseDto ObtenerTramoViaje(ConfiguracionTipoViajeFiltroDto request)
        {
            try
            {
                var objCondicionCliente = tb_STC_Programacion_Cabecera_ANX_ParametrosData.ListaModoViajePorCliente(request.RUC_Cliente, request.TipoViaje);
                request.CondicionViaje = objCondicionCliente.Codigo;
                var configuracionTipoViaje = tb_STC_ConfiguracionTipoViaje_CData.ListaTramos(request);
                var response = new ConfiguracionTipoViajeResponseDto
                {
                    CondicionViaje = objCondicionCliente.Descripcion,
                    ListaTramos = configuracionTipoViaje
                };
                return response;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region TRIPULACION

        public static Programacion_TripulacionResponseDto ObtenerEditorTripulacion(string id)
        {
            var resultado = tb_STC_Programacion_CabeceraData.ObtenerTripulacionUnidades(id);

            var result = new Programacion_TripulacionResponseDto()
            {
                TractoParametros = resultado
            };

            return result;
        }

        public static void InsertarProgramacionTripulacion(Programacion_TripulacionRequestDto request)
        {
            try
            {
                tb_STC_Programacion_CabeceraData.EliminarTripulacionUnidades(request.TractoParametros.ID_Index);

                var ID_Index = Convert.ToDecimal(request.TractoParametros.ID_Index);
                var tracto = new tb_STC_Programacion_Cabecera_ANX_Unidad
                {
                    Are_Codigo = request.TractoParametros.TractoCodigo,
                    ID_Index = ID_Index,
                    Tipo = Convert.ToByte(Constantes.TipoUnidad.UNIDAD),
                    Item = tb_STC_Programacion_Cabecera_ANX_UnidadData.ObtenerItem(ID_Index.ToString())
                };
                tb_STC_Programacion_Cabecera_ANX_UnidadData.Insertar(tracto);

                var carreta = new tb_STC_Programacion_Cabecera_ANX_Unidad
                {
                    Are_Codigo = request.TractoParametros.CarretaCodigo,
                    ID_Index = ID_Index,
                    Tipo = Convert.ToByte(Constantes.TipoUnidad.CARRETA),
                    Item = tb_STC_Programacion_Cabecera_ANX_UnidadData.ObtenerItem(ID_Index.ToString())
                };
                tb_STC_Programacion_Cabecera_ANX_UnidadData.Insertar(carreta);

                var piloto = new tb_STC_Programacion_Cabecera_ANX_Tripulacion
                {
                    Ben_Codigo = request.TractoParametros.PilotoCodigo,
                    ID_Index = ID_Index,
                    Tipo = Convert.ToByte(Constantes.TipoTripulacion.PILOTO),
                    Item = tb_STC_Programacion_Cabecera_ANX_TripulacionData.ObtenerItem(ID_Index.ToString())
                };
                tb_STC_Programacion_Cabecera_ANX_TripulacionData.Insertar(piloto);

                //ACTUALIZAR CONFIGURACION TRACTO
                tb_STC_Programacion_CabeceraData.InsertarTractoTripulacion(tracto.Are_Codigo, request.TractoParametros.UsuarioRegistro, carreta.Are_Codigo, piloto.Ben_Codigo);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static decimal EliminarProgramacionTripulacion(long id)
        {
            try
            {
                var entidad = tb_STC_Programacion_Cabecera_ANX_TripulacionData.ObtenerPorId(id);
                tb_STC_Programacion_Cabecera_ANX_TripulacionData.Eliminar(id);
                return entidad.ID_Index;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region UNIDAD

        public static Programacion_UnidadResponseDto ObtenerEditorUnidad(string id)
        {
            var resultado = tb_STC_Programacion_Cabecera_ANX_UnidadData.ListaProgramacion_Unidades(id);

            var result = new Programacion_UnidadResponseDto()
            {
                ListaUnidades = resultado,
                ListaTipos = tb_ConfiguracionDData.ListaConfiguracionD(302)
            };

            return result;
        }

        public static void InsertarProgramacionUnidad(Programacion_UnidadRequestDto request)
        {
            try
            {
                if (tb_STC_Programacion_Cabecera_ANX_UnidadData.ValidaExiste(request.Unidad))
                {
                    BusinessException.Generar("Ya ingreso estos datos anteriomente");
                }
                request.Unidad.Item = tb_STC_Programacion_Cabecera_ANX_UnidadData.ObtenerItem(request.Unidad.ID_Index.ToString());
                tb_STC_Programacion_Cabecera_ANX_UnidadData.Insertar(request.Unidad);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static decimal EliminarProgramacionUnidad(long id)
        {
            try
            {
                var entidad = tb_STC_Programacion_Cabecera_ANX_UnidadData.ObtenerPorId(id);
                tb_STC_Programacion_Cabecera_ANX_UnidadData.Eliminar(id);
                return entidad.ID_Index;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region DETALLE PARAMETROS

        public static List<ProgramacionDetalleParametroDto> InsertarDetalleParametros(ProgramacionDetalleParametroDto entidad)
        {
            var ent = new tb_STC_Programacion_Detalle_ANX_Parametros
            {
                ID_Index = entidad.ID_Index,
                Item = entidad.Item,
                TBG_Codigo = "09",
                TBG_Tabla = "02",
                Valor = entidad.Serie + "-" + entidad.Numero
            };
            tb_STC_Programacion_Detalle_ANX_ParametrosData.Insertar(ent);

            return tb_STC_Programacion_Detalle_ANX_ParametrosData.ListaDetalle(entidad.ID_Index, entidad.Item);
        }

        public static List<ProgramacionDetalleParametroDto> EliminarDetalleParametros(ProgramacionDetalleParametroDto entidad)
        {
            tb_STC_Programacion_Detalle_ANX_ParametrosData.EliminarPorCabecera((int)entidad.ID_Key);

            return tb_STC_Programacion_Detalle_ANX_ParametrosData.ListaDetalle(entidad.ID_Index, entidad.Item);
        }

        #endregion

        #region REPORTE

        public static FiltrosReporteEnvioResponseDto FiltrosReporteEnvio()
        {
            try
            {
                var response = new FiltrosReporteEnvioResponseDto
                {
                    ListaRutaViaje = TbgData.ListarPorTabla(_RutaViaje),
                };

                return response;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static List<ReporteEnvio> ReporteProgramacionEnvio(ReporteEnvioFiltroDto filtro)
        {
            try
            {
                var reporteResult = new List<ReporteEnvio>();
                var listaProgramaciones = tb_STC_Programacion_CabeceraData.ObtenerReporteProgramacion(filtro);
                foreach (var item in listaProgramaciones)
                {
                    var tramos = new List<ReporteTramos>();
                    tramos = tb_STC_Programacion_CabeceraData.ObtenerTramosPorReporteProgramacion(item.NroProgramacion);
                    reporteResult.Add(new ReporteEnvio { Programacion = item, ListaTramos = tramos });
                }
                return reporteResult;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static List<ReporteEnvio> ReporteProgramacionEnvioBD(ReporteEnvioFiltroDto filtro)
        {
            try
            {
                var reporteResult = new List<ReporteEnvio>();
                var listaProgramaciones = tb_STC_Programacion_CabeceraData.ObtenerReporteProgramacionBD(filtro);
                foreach (var item in listaProgramaciones)
                {
                    reporteResult.Add(new ReporteEnvio { Programacion = item });
                }
                return reporteResult;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        #endregion

    }
}
